
const defaultLinks=[
 {name:"Open Website",url:"https://example.com",description:"Add your destination URL"},
 {name:"Featured Link",url:"https://example.com",description:"Your featured destination"}
];
function getLinks(){try{return JSON.parse(localStorage.getItem("yoon_links"))||defaultLinks}catch{return defaultLinks}}
function saveLinks(x){localStorage.setItem("yoon_links",JSON.stringify(x))}
function renderHome(){
 const box=document.querySelector("#links"); if(!box)return;
 box.innerHTML=getLinks().map((l,i)=>`<a class="btn" href="redirect.html?i=${i}"><span><b>${esc(l.name)}</b><br><small>${esc(l.description||"External website")}</small></span><span>↗</span></a>`).join("");
}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function renderAdmin(){
 const box=document.querySelector("#manage"); if(!box)return;
 box.innerHTML=getLinks().map((l,i)=>`<div class="item"><div><b>${esc(l.name)}</b><div class="muted">${esc(l.url)}</div></div><button class="danger" onclick="removeLink(${i})">Delete</button></div>`).join("");
}
function removeLink(i){let x=getLinks();x.splice(i,1);saveLinks(x);renderAdmin()}
function addLink(e){e.preventDefault();let f=new FormData(e.target);let x=getLinks();x.push({name:f.get("name"),url:f.get("url"),description:f.get("description")});saveLinks(x);e.target.reset();renderAdmin();alert("Link added on this browser.")}
document.addEventListener("DOMContentLoaded",()=>{renderHome();renderAdmin();const f=document.querySelector("#addForm");if(f)f.addEventListener("submit",addLink)});
